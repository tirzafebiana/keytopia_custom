<?php

$con = mysqli_connect('localhost', 'id20904942_tirzafebiana', '@12Tirza', 'id20904942_keytopiacustomdatabase');

if (!$con) {
    die("<script>alert('Connection Failed.')</script>");

}

?>